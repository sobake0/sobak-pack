MuumaLand HQ MultiGlyph FIX

- 다중 글리프 4x2 타일 방식 유지
- 위/아래 행 렌더 순서 수정
- 메뉴 전체 캔버스에 라벤더/보라 배경을 합성해 투명 구멍 제거
- SOBAKShop/PointShop 리소스는 기존 파일 그대로 유지
- DeluxeMenus 클릭/슬롯 로직은 변경하지 않음
