MuumaLand HQ Multi-Glyph GUI Resource Pack

This pack preserves the original shop resources and adds tiled HQ menu glyphs.
Each HQ menu is split into 4 columns x 2 rows. Each tile stays <=256px per dimension.
U+F1F0 = -180px row rewind space.

main_menu: U+F100, U+F101, U+F102, U+F103, U+F104, U+F105, U+F106, U+F107
move_select: U+F110, U+F111, U+F112, U+F113, U+F114, U+F115, U+F116, U+F117
wild_select: U+F120, U+F121, U+F122, U+F123, U+F124, U+F125, U+F126, U+F127
dimension_select: U+F130, U+F131, U+F132, U+F133, U+F134, U+F135, U+F136, U+F137
island_expand: U+F140, U+F141, U+F142, U+F143, U+F144, U+F145, U+F146, U+F147
